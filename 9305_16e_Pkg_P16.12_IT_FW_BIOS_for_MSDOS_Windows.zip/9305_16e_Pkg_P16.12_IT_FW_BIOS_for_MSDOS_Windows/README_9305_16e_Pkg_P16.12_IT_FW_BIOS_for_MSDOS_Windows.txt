***********************************************************************************************************************
Package for SAS3 Phase 16 Firmware BIOS Upgrade on MSDOS & Windows
************************************************************************************************************************
LSI Host Bus Adapter(HBA) - LSI SAS9305_16e

Package Contents- 

Readme first note      :  README_9305_16e_Pkg_P16.12_IT_FW_BIOS_for_MSDOS_Windows.txt 


Component                                : Path                                                         Version              Release Date        
============================================================================================================================================
Firmware                                 : \firmware\SAS9305_16e_IT_P\SAS9305_16e_IT_P.bin              16.00.12.00          02-NOV-20           
Firmware                                 : \firmware\SAS9305_16e_IT_ACM_P\SAS9305_16e_IT_ACM_P.bin      16.00.12.00          02-NOV-20           

BIOS                                     : \sasbios_rel\mptsas3.rom                                     08.37.02.00          02-MAR-20           
Readme for BIOS                          : \sasbios_rel\mptbios.txt                                     NA                   NA                  

UEFI BSD (Signed)                        : \uefi_bsd_rel\Signed\mpt3x64.rom                             18.00.03.00          20-FEB-20
UEFI BSD (Unsigned)                      : \uefi_bsd_rel\Signed\mpt3x64.rom                             18.00.03.00          20-FEB-20
Driver Sign Info for UEFI BSD            : \uefi_bsd_rel\DriverSignInfo.txt                             NA                   NA
Readme for UEFI BSD                      : \uefi_bsd_rel\readme_SAS3_UEFI_BSD_HII.txt                   NA                   NA

Installer(SAS3FLSH) DOS                  : \sas3flash_dos_rel\sas3flash.exe                             17.00.00.00          05-APR-18           
Installer(SAS3FLASH) Win x86             : \sas3flash_win_x86_rel\sas3flash.exe                         17.00.00.00          05-APR-18           
Installer(SAS3FLASH) Win x64             : \sas3flash_win_x64_rel\sas3flash.exe                         17.00.00.00          05-APR-18
          
Reference Guide                          : sas3flash_ReferenceGuide.pdf                                 1.0                  03-OCT-14

Firmware Release Notes                   : Intruder_Release_Notes_16.00.11.00.pdf                       NA                   NA
BIOS Release Notes                       : BIOS_MPT_GEN3_Phase16-8.37.01.00.pdf                         NA                   NA
UEFI BSD Release Notes                   : UEFIBSDHII_MPT_GEN3_Phase16-18.00.03.00.pdf                  NA                   NA



----------------------------------------------------------------------------------------------------------------------------

